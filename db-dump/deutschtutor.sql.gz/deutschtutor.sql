--
-- PostgreSQL database dump
--

\restrict Ek27cFGg1Q77c3hI7PQePIYJQhqvIvq24b3lslPEELQmYpyPJT022CLP8tdgq7R

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vocabulary DROP CONSTRAINT IF EXISTS vocabulary_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.schreiben_submissions DROP CONSTRAINT IF EXISTS schreiben_submissions_pkey;
ALTER TABLE IF EXISTS ONLY public.review_queue DROP CONSTRAINT IF EXISTS review_queue_pkey;
ALTER TABLE IF EXISTS ONLY public.goals DROP CONSTRAINT IF EXISTS goals_pkey;
ALTER TABLE IF EXISTS ONLY public.errors DROP CONSTRAINT IF EXISTS errors_pkey;
ALTER TABLE IF EXISTS ONLY public.daily_stats DROP CONSTRAINT IF EXISTS daily_stats_pkey;
ALTER TABLE IF EXISTS ONLY public.daily_stats DROP CONSTRAINT IF EXISTS daily_stats_date_key;
ALTER TABLE IF EXISTS public.vocabulary ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.schreiben_submissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.review_queue ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.goals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.errors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.daily_stats ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.vocabulary_id_seq;
DROP TABLE IF EXISTS public.vocabulary;
DROP SEQUENCE IF EXISTS public.sessions_id_seq;
DROP TABLE IF EXISTS public.sessions;
DROP SEQUENCE IF EXISTS public.schreiben_submissions_id_seq;
DROP TABLE IF EXISTS public.schreiben_submissions;
DROP SEQUENCE IF EXISTS public.review_queue_id_seq;
DROP TABLE IF EXISTS public.review_queue;
DROP SEQUENCE IF EXISTS public.goals_id_seq;
DROP TABLE IF EXISTS public.goals;
DROP SEQUENCE IF EXISTS public.errors_id_seq;
DROP TABLE IF EXISTS public.errors;
DROP SEQUENCE IF EXISTS public.daily_stats_id_seq;
DROP TABLE IF EXISTS public.daily_stats;
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: daily_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_stats (
    id integer NOT NULL,
    date text NOT NULL,
    messages_sent integer DEFAULT 0,
    vocab_learned integer DEFAULT 0,
    vocab_reviewed integer DEFAULT 0,
    errors_made integer DEFAULT 0,
    errors_resolved integer DEFAULT 0,
    avg_quality real DEFAULT 0,
    minutes_studied integer DEFAULT 0,
    streak_days integer DEFAULT 0
);


--
-- Name: daily_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_stats_id_seq OWNED BY public.daily_stats.id;


--
-- Name: errors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.errors (
    id integer NOT NULL,
    original_text text NOT NULL,
    corrected_text text NOT NULL,
    explanation text NOT NULL,
    category text NOT NULL,
    subcategory text,
    grammar_topic_id text,
    source text,
    source_context text,
    times_repeated integer DEFAULT 1,
    resolved boolean DEFAULT false,
    last_seen_at text DEFAULT now(),
    created_at text DEFAULT now()
);


--
-- Name: errors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.errors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: errors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.errors_id_seq OWNED BY public.errors.id;


--
-- Name: goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goals (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    category text,
    target_value integer DEFAULT 100,
    current_value integer DEFAULT 0,
    completed boolean DEFAULT false,
    created_at text DEFAULT now()
);


--
-- Name: goals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goals_id_seq OWNED BY public.goals.id;


--
-- Name: review_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_queue (
    id integer NOT NULL,
    item_type text NOT NULL,
    item_id integer NOT NULL,
    due_at text NOT NULL,
    difficulty real DEFAULT 0.3,
    stability real DEFAULT 1.0,
    reps integer DEFAULT 0,
    lapses integer DEFAULT 0,
    last_review_at text,
    created_at text DEFAULT now()
);


--
-- Name: review_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: review_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_queue_id_seq OWNED BY public.review_queue.id;


--
-- Name: schreiben_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schreiben_submissions (
    id integer NOT NULL,
    task_text text NOT NULL,
    user_text text NOT NULL,
    corrected_text text,
    scores text,
    total_score integer,
    feedback text,
    improvement_tips text,
    created_at text DEFAULT now()
);


--
-- Name: schreiben_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.schreiben_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schreiben_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.schreiben_submissions_id_seq OWNED BY public.schreiben_submissions.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    scenario_id text NOT NULL,
    scenario_title text NOT NULL,
    mode text NOT NULL,
    messages text NOT NULL,
    analysis_results text,
    stats text,
    duration_minutes integer,
    created_at text DEFAULT now()
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: vocabulary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vocabulary (
    id integer NOT NULL,
    word_de text NOT NULL,
    word_pt text NOT NULL,
    example_sentence text,
    category text,
    gender text,
    plural text,
    tags text,
    collocations text,
    word_family text,
    times_seen integer DEFAULT 0,
    times_produced integer DEFAULT 0,
    times_failed integer DEFAULT 0,
    ease_factor real DEFAULT 2.5,
    interval_days integer DEFAULT 0,
    next_review_at text,
    created_at text DEFAULT now(),
    updated_at text DEFAULT now()
);


--
-- Name: vocabulary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vocabulary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vocabulary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vocabulary_id_seq OWNED BY public.vocabulary.id;


--
-- Name: daily_stats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_stats ALTER COLUMN id SET DEFAULT nextval('public.daily_stats_id_seq'::regclass);


--
-- Name: errors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.errors ALTER COLUMN id SET DEFAULT nextval('public.errors_id_seq'::regclass);


--
-- Name: goals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goals ALTER COLUMN id SET DEFAULT nextval('public.goals_id_seq'::regclass);


--
-- Name: review_queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_queue ALTER COLUMN id SET DEFAULT nextval('public.review_queue_id_seq'::regclass);


--
-- Name: schreiben_submissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schreiben_submissions ALTER COLUMN id SET DEFAULT nextval('public.schreiben_submissions_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: vocabulary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vocabulary ALTER COLUMN id SET DEFAULT nextval('public.vocabulary_id_seq'::regclass);


--
-- Data for Name: daily_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_stats (id, date, messages_sent, vocab_learned, vocab_reviewed, errors_made, errors_resolved, avg_quality, minutes_studied, streak_days) FROM stdin;
1	2026-03-04	1	0	0	5	0	0	0	0
13	2026-03-05	0	0	0	0	0	0	0	0
14	2026-03-06	0	0	0	0	0	0	0	0
15	2026-03-08	1	2	0	0	0	9	0	0
19	2026-03-16	0	0	0	0	0	0	0	0
20	2026-03-26	0	0	0	0	0	0	0	0
21	2026-03-28	0	0	0	0	0	0	0	0
\.


--
-- Data for Name: errors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.errors (id, original_text, corrected_text, explanation, category, subcategory, grammar_topic_id, source, source_context, times_repeated, resolved, last_seen_at, created_at) FROM stdin;
2	1 erro de associação	der Verein=clube/associação, teilnehmen=participar, die Veranstaltung=evento, sich erholen=descansar/recuperar-se	'Der Verein' é a associação ou clube (esportivo, cultural etc.). 'Teilnehmen' rege 'an + Dativo': 'an einem Kurs teilnehmen'. 'Die Veranstaltung' é qualquer evento organizado. 'Sich erholen' é o verbo reflexivo para recuperar energias — muito usado após plantões médicos longos!	vocabulary	connect	\N	wortschatz	\N	1	f	2026-03-04 07:16:50.376467+00	2026-03-04 07:16:50.376467+00
3	Nachher dem Dienst, ich mir in ein Veraarde melden	Nach dem Dienst melde ich mich in einem Schwimmverein an.	'Sich anmelden' é um verbo separável: o prefixo 'an' vai para o final da oração principal — 'melde ich mich ... an'. A preposição correta com 'Verein' é 'in einem Verein' (membro dentro do clube) ou 'bei einem Verein' (ambas aceitas). 'Der Dienst' é o equivalente natural de 'plantão' no contexto médico alemão.	vocabulary	translate	\N	wortschatz	\N	1	f	2026-03-04 07:16:50.385157+00	2026-03-04 07:16:50.385157+00
4	Am der Wochenende trainiert er zweimal mit Fußballmannschaft.	Am Wochenende trainiert er zweimal mit der Fußballmannschaft.	Em alemão, quando um advérbio ou expressão de tempo ocupa a primeira posição ('Am Wochenende'), o verbo conjugado vem logo em seguida (posição V2), e o sujeito aparece depois: 'trainiert er'. 'Mit der Fußballmannschaft' usa Dativo porque 'mit' rege sempre o Dativo.	vocabulary	sentenceBuild	\N	wortschatz	\N	1	f	2026-03-04 07:16:50.391109+00	2026-03-04 07:16:50.391109+00
5	Er	teil	'Teilnehmen an + Dativo' significa participar de algo. Como é um verbo separável, o prefixo 'teil' se separa e vai para o final da oração: 'sie nimmt ... teil'. Não confunda com 'teilweise' (parcialmente), que é advérbio e não se separa.	vocabulary	cloze	\N	wortschatz	\N	1	f	2026-03-04 07:16:50.396552+00	2026-03-04 07:16:50.396552+00
6	Im Sportverein	Im Sportverein kann man sich gut entspannen und neue Leute kennenlernen.	'Sich entspannen' (relaxar) e 'kennenlernen' (conhecer pessoas) são dois verbos-chave de Freizeit. Note que 'kennenlernen' é escrito junto como um único verbo separável. 'Man' é o pronome impessoal equivalente ao 'se' do português: 'pode-se relaxar bem'.	vocabulary	memoryFlash	\N	wortschatz	\N	1	f	2026-03-04 07:16:50.401694+00	2026-03-04 07:16:50.401694+00
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goals (id, title, description, category, target_value, current_value, completed, created_at) FROM stdin;
\.


--
-- Data for Name: review_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.review_queue (id, item_type, item_id, due_at, difficulty, stability, reps, lapses, last_review_at, created_at) FROM stdin;
6	error	3	2026-03-04T07:16:50.386Z	0.3	1	0	0	\N	2026-03-04 07:16:50.38706+00
7	error	4	2026-03-04T07:16:50.392Z	0.3	1	0	0	\N	2026-03-04 07:16:50.392877+00
8	error	5	2026-03-04T07:16:50.397Z	0.3	1	0	0	\N	2026-03-04 07:16:50.398376+00
9	error	6	2026-03-04T07:16:50.402Z	0.3	1	0	0	\N	2026-03-04 07:16:50.403379+00
10	vocabulary	4	2026-03-09T13:41:54.677Z	0.3	1	0	0	\N	2026-03-08 13:41:54.678398+00
11	vocabulary	5	2026-03-09T13:42:08.473Z	0.3	1	0	0	\N	2026-03-08 13:42:08.474758+00
5	error	2	2026-03-28T01:38:07.715Z	1	2.4	1	0	2026-03-28T00:54:55.715Z	2026-03-04 07:16:50.380818+00
\.


--
-- Data for Name: schreiben_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schreiben_submissions (id, task_text, user_text, corrected_text, scores, total_score, feedback, improvement_tips, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, scenario_id, scenario_title, mode, messages, analysis_results, stats, duration_minutes, created_at) FROM stdin;
1	praesentation-wohnen	Präsentation: Wohnen in der Stadt	chat	[{"role":"user","content":"Ich liebe dich","parsed":null},{"role":"assistant","content":"Oh, das ist süß! Aber ich glaube, wir sollten über dein Thema sprechen – Wohnen in der Stadt oder auf dem Land. Das ist bestimmt interessanter! Wo wohnst du gerade, und was denkst du darüber?","parsed":{"response":"Oh, das ist süß! Aber ich glaube, wir sollten über dein Thema sprechen – Wohnen in der Stadt oder auf dem Land. Das ist bestimmt interessanter! Wo wohnst du gerade, und was denkst du darüber?","translation":"Oh, que fofo! Mas acho que devemos falar sobre o seu tema – morar na cidade ou no campo. Com certeza é mais interessante! Onde você mora atualmente, e o que você acha disso?","keyVocab":[{"de":"bestimmt","pt":"com certeza / definitivamente","example":"Das ist bestimmt eine gute Idee."}],"grammarNote":"A palavra 'sollten' é o Konjunktiv II de 'sollen' e expressa uma sugestão educada – como 'deveríamos'. Ex: 'Wir sollten sprechen' = 'Nós deveríamos falar'.","_provider":"Claude Sonnet 4.6","_model":"anthropic/claude-sonnet-4-6","_wasFallback":false,"_durationMs":6695}}]	\N	\N	\N	2026-03-08 13:41:54.665949+00
\.


--
-- Data for Name: vocabulary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vocabulary (id, word_de, word_pt, example_sentence, category, gender, plural, tags, collocations, word_family, times_seen, times_produced, times_failed, ease_factor, interval_days, next_review_at, created_at, updated_at) FROM stdin;
4	bestimmt	com certeza / definitivamente	Das ist bestimmt eine gute Idee.	\N	\N	\N	\N	\N	\N	0	0	0	2.5	0	2026-03-09T13:41:54.671Z	2026-03-08 13:41:54.67228+00	2026-03-08 13:41:54.67228+00
5	lieben		jemanden von ganzem Herzen lieben (amar alguém de todo o coração), sich ineinander verlieben (apaixonar-se um pelo outro), Ich liebe es, Deutsch zu lernen (Eu adoro aprender alemão — lieben + Infinitivkonstruktion), die Liebe auf den ersten Blick (amor à primeira vista)	\N	\N	\N	\N	\N	\N	0	0	0	2.5	0	2026-03-09T13:42:08.467Z	2026-03-08 13:42:08.468078+00	2026-03-08 13:42:08.468078+00
\.


--
-- Name: daily_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_stats_id_seq', 21, true);


--
-- Name: errors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.errors_id_seq', 6, true);


--
-- Name: goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goals_id_seq', 1, false);


--
-- Name: review_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.review_queue_id_seq', 11, true);


--
-- Name: schreiben_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.schreiben_submissions_id_seq', 1, false);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, true);


--
-- Name: vocabulary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vocabulary_id_seq', 5, true);


--
-- Name: daily_stats daily_stats_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_stats
    ADD CONSTRAINT daily_stats_date_key UNIQUE (date);


--
-- Name: daily_stats daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_stats
    ADD CONSTRAINT daily_stats_pkey PRIMARY KEY (id);


--
-- Name: errors errors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.errors
    ADD CONSTRAINT errors_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: review_queue review_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_queue
    ADD CONSTRAINT review_queue_pkey PRIMARY KEY (id);


--
-- Name: schreiben_submissions schreiben_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schreiben_submissions
    ADD CONSTRAINT schreiben_submissions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: vocabulary vocabulary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vocabulary
    ADD CONSTRAINT vocabulary_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict Ek27cFGg1Q77c3hI7PQePIYJQhqvIvq24b3lslPEELQmYpyPJT022CLP8tdgq7R

